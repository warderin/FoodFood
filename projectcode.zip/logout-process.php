<?php

	session_start();
	session_unset();
	session_destroy();

?>

<!doctype HTML>

<html>

	<head>

		<title>FoodFood</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="style/style.css">
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

	</head>

	<body>

		<h2 style="text-align:center;margin-top:75px;"> logging out... </h2>
		<p style="text-align:center"> you will be redirected to the login page </p>

	<script>

		setTimeout(function() {
			window.location.replace("login.php");
		}, 3000);

	</script>

	</body>

</html>