<?php session_start(); ?>

<!doctype html>

<html>

<head>

	<title>FoodFood</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

</head>

<body>

<?php
 	
	if(!$_SESSION['userID']) {
	
?>
	<h2 style="text-align:center">Please log in here: <a href='login.php'>Login Page</a></h2>
<?php
		exit();
	}
	
	else {

?>

	<section class="mainlogo">
		<div id="mainlink">
				<a href="addrecipe.php">add a new recipe</a>
		</div>
		<div id="mainimage">
			<a href="main.php"><img src="images/logosmall.png"></a>
		</div>
		<div id="mainlink">
			<a href="user.php">my account</a>
		</div>
	</section>

	<section id="foodnav">
		<li id="all">all recipes</li>
		<li id="break">breakfast</li>
		<li id="lunch">lunch</li>
		<li id="dinner">dinner</li>
	</section>

	<section id="foodfeed">


	</section>

	<div id="logout"><a href="logout-process.php">Log me out</a></div>

<script>

document.addEventListener("DOMContentLoaded", allClicked);

document.getElementById("all").addEventListener("click", allClicked, false);
document.getElementById("break").addEventListener("click", breakfastClicked, false);
document.getElementById("lunch").addEventListener("click", lunchClicked, false);
document.getElementById("dinner").addEventListener("click", dinnerClicked, false);

var myRequest = new XMLHttpRequest;

function allClicked(e){
	myRequest.open("GET", "getdata.php", true); //true means it is asynchronous // Send urls through the url
	myRequest.send(); 
} 

function breakfastClicked(e){
	myRequest.open("GET", "getbreakfast.php", true); //true means it is asynchronous // Send urls through the url
	myRequest.send(); 
}

function lunchClicked(e){
	myRequest.open("GET", "getlunch.php", true); //true means it is asynchronous // Send urls through the url
	myRequest.send(); 
}

function dinnerClicked(e){
	myRequest.open("GET", "getdinner.php", true); //true means it is asynchronous // Send urls through the url
	myRequest.send(); 
}

function overlayOn(popupTitle, popupUser, popupDate, popupIng, popupIns, popupPic, popupCats, popupSource) {
	var popup = document.createElement('div');
	popup.setAttribute("id", "overlay");
	var innerpopup = document.createElement('div');
	var popuptext = document.createElement('p');
	popuptext.innerHTML = "<h2 style='font-size:30px;'>" + popupTitle + "</h2><img class='icon' src='" + popupPic + "'><h5 style='margin-bottom:-7px;'>Posted by <b>" + popupUser + "</b> in " + popupCats + " on " + popupDate + "<br>Source: " + popupSource + "</h5><h5 style='margin-bottom:-10px;'>Ingredients:</h5><p>" + popupIng + "</p><h5 style='margin-bottom:-10px;'>Instructions:</h5><p>" + popupIns + "</p><p>Click here to <button onclick='overlayOff()'>close</button></p>";	
	innerpopup.appendChild(popuptext);
	popup.appendChild(innerpopup);
	var bodys = document.getElementsByTagName('body');
	var body = bodys[0];
	body.appendChild(popup);
	el = document.getElementById("overlay");
	el.style.visibility = "visible";

}

function overlayOff() {
	el = document.getElementById("overlay");
	el.style.visibility = "hidden";
	document.location.reload();
}

myRequest.onreadystatechange = function(){          
	if(myRequest.readyState === 4){   
		
		console.log(myRequest.responseText);
		var xmlDoc = myRequest.responseXML;
		var tags = xmlDoc.getElementsByTagName('recipe'); 
		console.log(tags.length);   
		
		var feed = document.getElementById("foodfeed");
		feed.innerHTML = "";
		
		for (var i=0;i<tags.length;i++){
			
			var foodcard = document.createElement('div');
			foodcard.setAttribute('id', 'foodcard');
			feed.appendChild(foodcard);
			var photos = xmlDoc.getElementsByTagName('photo');
			var w = document.createTextNode(photos[i].firstChild.nodeValue)
			foodcard.innerHTML = '<img class="food" src="' + (photos[i].firstChild.nodeValue) + '">';
			var titles = xmlDoc.getElementsByTagName('title');
			var x = document.createTextNode(titles[i].firstChild.nodeValue);
			var foodtitle = document.createElement('h2');
			foodtitle.appendChild(x);						
			foodcard.appendChild(foodtitle);
			var users = xmlDoc.getElementsByTagName('author');
			var y = document.createTextNode("By " + (users[i].firstChild.nodeValue) + " ");
			var foodmeta = document.createElement('h5');
			foodmeta.appendChild(y);
			var dates = xmlDoc.getElementsByTagName('dateAdded');
			var z = document.createTextNode("on " + (dates[i].firstChild.nodeValue));
			foodmeta.appendChild(z);
			foodcard.appendChild(foodmeta);		
			var popupTitle = document.createElement('p');
			popupTitle.innerHTML = (titles[i].firstChild.nodeValue);
			var popupUser = document.createElement('p');
			popupUser.innerHTML = (users[i].firstChild.nodeValue);
			var popupDate = document.createElement('p');
			popupDate.innerHTML = (dates[i].firstChild.nodeValue);
			var ingr = xmlDoc.getElementsByTagName('ingredients');
			var popupIng = document.createElement('p');
			popupIng.innerHTML = (ingr[i].firstChild.nodeValue);
			var inst = xmlDoc.getElementsByTagName('instructions');
			var popupIns = document.createElement('p');
			popupIns.innerHTML = (inst[i].firstChild.nodeValue);
			var popupPic = document.createElement('p');
			popupPic.innerHTML = (photos[i].firstChild.nodeValue);
			var cats = xmlDoc.getElementsByTagName('category');
			var popupCats = document.createElement('p');
			popupCats.innerHTML = (cats[i].firstChild.nodeValue);
			var sources = xmlDoc.getElementsByTagName('source');
			var popupSource = document.createElement('p');
			popupSource.innerHTML = (sources[i].firstChild.nodeValue);
			foodcard.onclick = Function("overlayOn('" + (popupTitle.innerHTML.replace(/'/g, "\\'")) + "', '" + (popupUser.innerHTML.replace(/'/g, "\\'")) + "', '" + (popupDate.innerHTML) + "', '" + (popupIng.innerHTML.replace(/'/g, "\\'")) + "', '" + (popupIns.innerHTML.replace(/'/g, "\\'")) + "', '" + (popupPic.innerHTML) + "', '" + (popupCats.innerHTML) + "', '" + (popupSource.innerHTML.replace(/'/g, "\\'")) + "')");
			
		}                                                                                                          
		
	} 
};

</script>

</body>

</html>

<?php } ?>