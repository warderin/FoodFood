<?php session_start(); 

$userEmail = $_POST['email'];
$userFirst = $_POST['first'];
$userLast = $_POST['last'];
$userTown = $_POST['town'];
$userProvince = $_POST['province'];
$userAbout = $_POST['about'];
$userWebsite = $_POST['website'];
$username = $_POST['newUser'];
$userPassword = $_POST['newPassword'];

$string = preg_replace('/\s+/', '', (basename( $_FILES['file_upload']['name'])));

$target = "/~warderi/foodfood/images/user/";
$target = $target . $string;

if(!move_uploaded_file($_FILES['file_upload']['tmp_name'], 'images/user/' . $string)){     
	$target = "images/user.png"; 
}

$allowed =  array('gif','png','jpg');
$filename = $_FILES['file_upload']['name'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) ) {
    $target = "images/user.png"; 
}

?>


<!DOCTYPE html>

<html>

	<head>

		<title>Signup Done</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="style/style.css">
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

	</head>

<body>

<?php
// check database for correct username/password

$dsn = "mysql:host=localhost;dbname=warderi";
$dbusername='warderi';
$dbpassword='991252147';

$pdo = new PDO($dsn, $dbusername, $dbpassword);

$check = $pdo->prepare("SELECT `username` FROM `users` WHERE `username` = '" . $username . "' ");

$check->execute();

if($check->rowCount() > 0){
        $username = "";
        echo "<center>That username is taken, try something else!</center>";
} 
else {
	if (strlen($userEmail) > 7 && strlen($userFirst) > 0 && strlen($userLast) > 0 && strlen($userAbout) > 1 && strlen($username) > 2 && strlen($userPassword) > 5) {

	$stmt = $pdo->prepare("INSERT INTO `warderi`.`users` (`email`, `firstName`, `lastName`, `town`, `prov`, `about`, `userPhoto`, `website`, `username`, `password`) VALUES ('" . $userEmail . "', '" . $userFirst . "', '" . $userLast . "', '" . $userTown . "', '" . $userProvince . "', '" . $userAbout . "', '" . $target . "', '" . $userWebsite . "', '" . $username . "', '" . $userPassword . "');");

	$stmt->execute();

	}

	else {

		echo "<center>You must fill out all mandatory fields</center>";
	}
}

$stmt2 = $pdo->prepare("SELECT `userID`, `firstName` FROM `users` WHERE `username` = '" . $username . "' AND `password` = '" . $userPassword . "' ");

$stmt2->execute();

$row = $stmt2->fetch();

if($row) {

?>

	<h2 style="margin-top:75px;text-align:center">Welcome, <?php echo($row['firstName']); ?> you are logged in!</h2>
	<h1 style="text-align:center"><a href="main.php">Continue to foodfood!</a></h1>

<?php

$_SESSION['userID'] = $row['userID'];

}

else {

?>

	<h2 style="margin-top:75px;text-align:center;">Sorry, something went wrong, please <a href="signup.php">try again</a></h2>

<?php
}

$pdo = null;

?>

</body>

</html>
