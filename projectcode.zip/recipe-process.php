<?php session_start(); 

$title = $_POST['title'];
$author = $_SESSION['username'];
$source = $_POST['source'];
$category = $_POST['category'];
$ingredients = $_POST['ingredients'];
$instructions = $_POST['instructions'];
$date = date('Y-m-d');

$string = preg_replace('/\s+/', '', (basename( $_FILES['file_upload']['name'])));



$target = "/~warderi/foodfood/images/recipe/";
$target = $target . $string;

if(!move_uploaded_file($_FILES['file_upload']['tmp_name'], 'images/recipe/' . $string)){     
	$target = "images/default.png"; 
}

$allowed =  array('gif','png','jpg');
$filename = $_FILES['file_upload']['name'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) ) {
    $target = "images/default.png"; 
}


?>


<!DOCTYPE html>

<html>

<head>
<title>FoodFood - Add Recipe</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="style/style.css">
<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

</head>

<body>

<?php
// check database for correct username/password

$dsn = "mysql:host=localhost;dbname=warderi";
$dbusername='warderi';
$dbpassword='991252147';

$pdo = new PDO($dsn, $dbusername, $dbpassword);

$newID = $pdo->prepare("SELECT COUNT(*) FROM recipes;");

$newID->execute();

$IDarray = $newID->fetch();

$IDnum = $IDarray[0] + 1;

if (strlen($title) > 1 && strlen($ingredients) > 1 && strlen($instructions) > 1) {

$stmt = $pdo->prepare("INSERT INTO `warderi`.`recipes` (`title`, `author`, `source`, `category`, `ingredients`, `instructions`, `dateAdded`, `photo`) VALUES ('" . $title . "', '" . $author . "', '" . $source . "', '" . $category . "', '" . $ingredients . "', '" . $instructions . "', '" . $date . "', '". $target ."');");

$stmt->execute();

}

else {
echo "<center>You must fill out all mandatory fields</center>";
}

$stmt2 = $pdo->prepare("SELECT `title` FROM `recipes` WHERE `title` = '" . $title . "' ");

$stmt2->execute();

$row = $stmt2->fetch();


// print_r($row); //recursive print out

if($row) {

?>

<h2 style="margin-top:75px;text-align:center"><?php echo($row['title']); ?> has been added!</h2>
<h1 style="text-align:center"><a href="main.php">Back to foodfood!</a></h1>

<?php


}

else {

?>

<h2 style="margin-top:75px;text-align:center;">Sorry, something went wrong, please <a href="addrecipe.php">try again</a></h2>

<?php

}

$pdo = null;

?>

</body>

</html>