<?php session_start(); 

?>

<!doctype html>

<html>

<head>

	<title>FoodFood - Add Recipe</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

</head>

<body>

<?php 
	if(!$_SESSION['userID']) {
?>
		<h2 style="text-align:center">Please log in here: <a href='login.php'>Login Page</a></h2>
<?php
		exit();
	}
	else {

?>

	<section class="mainlogo">
		<div id="mainlink">
			<a href="addrecipe.php">add a new recipe</a>
		</div>
		<div id="mainimage">
			<a href="main.php"><img src="images/logosmall.png"></a>
		</div>
		<div id="mainlink">
			<a href="user.php">my account</a>
		</div>
	</section>

	<h1 style="clear:both;">Add a Recipe</h1>

	<section id="recipeSec">

		<form id="recipe" enctype="multipart/form-data" action="recipe-process.php" method="POST">

			<p style="text-align:right;">* denotes required field</p>

			<label for="title">title: *</label>

			<input type="text" name="title" />
			<br><br>
			<label for="source">source:</label>

			<input type="text" name="source" />
			<br><br>
			<label for="category">category: *</label>

			<select name="category">

				<option>Breakfast</option>
				<option>Lunch</option>
				<option>Dinner</option>
				<option>Dessert</option>

			</select>
			<br><br>
			ingredients: *

			<textarea rows="10" cols="54" name="ingredients" placeholder="List ingredients here..."></textarea>
			<br><br>
			instructions: *

			<textarea rows="10" cols="54" name="instructions" placeholder="List instructions here..."></textarea>
			<br><br>
			<label for="file_upload">photo (jpg, gif, or png - max. 2MB):</label>
			<p>
				<input type="hidden" name="MAX_FILE_SIZE" value="2048000" />
				<input type='file' name='file_upload' />
			</p>
			<br><br>
			<center>
				<input type="submit" value="Add Recipe" id="submit" style="height:50px;"/>
			</center>
			<br><br>
			
		</form>
	
	</section>

	<div id="logout"><a href="logout-process.php">Log me out</a></div>

</body>

</html>

<?php } ?>