<?php session_start(); 

?>

<!doctype html>

<html>

	<head>

		<title>FoodFood</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="style/style.css">
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

	</head>

	<body>

<?php 

if(!$_SESSION['userID']) {

?>
		<h2 style="text-align:center">Please log in here: <a href='login.php'>Login Page</a></h2>
<?php

	exit();
}

else {

?>

		<section class="mainlogo">
			<div id="mainlink">
				<a href="addrecipe.php">add a new recipe</a>
			</div>
			<div id="mainimage">
				<a href="main.php"><img src="images/logosmall.png"></a>
			</div>
			<div id="mainlink">
				<a href="user.php">my account</a>
			</div>
		</section>

		<section id="user">

<?php

$dsn = "mysql:host=localhost;dbname=warderi";
$dbusername='warderi';
$dbpassword='991252147';

$pdo = new PDO($dsn, $dbusername, $dbpassword);

$userID = $_SESSION['userID'];

$stmt = $pdo->prepare("SELECT `username`, `firstName`, `lastName`, `website`, `about`, `town`, `prov`, `userPhoto` FROM `users` WHERE `userID` = '" . $userID . "' ");

$stmt->execute();

$row = $stmt->fetch();

$stmt2 = $pdo->prepare("SELECT `recipeID`, `title`, `author`, `source`, `category`, `ingredients`, `instructions`, `dateAdded` FROM `recipes` WHERE `author` = '" . $row['username'] . "' ORDER BY `recipeID` DESC ");

$stmt2->execute();

$row2 = $stmt2->fetch();

?>

		<section id="basicinfo">
			<h3><?php echo($row['username']); ?></h3>
			<h2 style="margin-bottom: -3px;margin-top: -25px;"><?php echo($row['firstName']); ?> <?php echo($row['lastName']); ?> <font color="#262626"><br> <?php echo($row['town']); ?>, <?php echo($row['prov']); ?></font></h2>

			<p>
				<a href="<?php echo($row['website']); ?>"><?php echo($row['website']); ?></a>
			</p>
			About me:

			<p><?php echo($row['about']); ?></p>
		</section>

		<img id="profile" src="<?php echo($row['userPhoto']); ?>">

		<section id="userPosts">

<script>

document.addEventListener("DOMContentLoaded", allClicked);

var myRequest = new XMLHttpRequest;

function allClicked(e){
	myRequest.open("GET", "getuserdata.php", true); //true means it is asynchronous // Send urls through the url
	myRequest.send(); 
} 


myRequest.onreadystatechange = function(){     
	// console.log(myRequest.readyState);     
	if(myRequest.readyState === 4){   
		
		// console.log(myRequest.responseText);
		var xmlDoc = myRequest.responseXML;
		var tags = xmlDoc.getElementsByTagName('recipe'); 
		// console.log(tags.length);    
		
		var feed = document.getElementById("userPosts");
		feed.innerHTML = "";
		
		for (var i=0;i<tags.length;i++){
			var foodcard = document.createElement('div');
			foodcard.setAttribute('id', 'userfoodcard');
			feed.appendChild(foodcard);
			
			var foodcardleft = document.createElement('div');
			foodcardleft.setAttribute('id', 'ufcleft');
			var photos = xmlDoc.getElementsByTagName('photo');
			var w = document.createTextNode(photos[i].firstChild.nodeValue)
			foodcardleft.innerHTML = '<img class="icon" src="' + (photos[i].firstChild.nodeValue) + '">';
			
			var foodcardright = document.createElement('div');
			foodcardright.setAttribute('id', 'ufcright');
			var titles = xmlDoc.getElementsByTagName('title');
			var x = document.createTextNode(titles[i].firstChild.nodeValue);
			var foodtitle = document.createElement('h2');
			foodtitle.appendChild(x);
			foodcardright.appendChild(foodtitle);
			
			var editform = document.createElement('form');
			editform.setAttribute("action", "edit.php");
			editform.setAttribute("method", "POST");
			
			var ids = xmlDoc.getElementsByTagName('recipeID');

			var input = document.createElement('input');
			input.setAttribute("type", "text");
			input.setAttribute("name", "edit");
			input.setAttribute("value", ids[i].firstChild.nodeValue);
			input.setAttribute("style", "display:none;");
			editform.appendChild(input);
			
			var submit = document.createElement('input');
			submit.setAttribute("type", "submit");
			submit.setAttribute("value", "Edit");
			submit.setAttribute("id", "Submit");
			editform.appendChild(submit);
				
			foodcardright.appendChild(editform);
			
			foodcard.appendChild(foodcardleft);
			foodcard.appendChild(foodcardright);
			
		}                                                                                                         
		
	} 
};

</script>

			</section>

		</section>

		<div id="logout"><a href="logout-process.php">Log me out</a></div>

	</body>

</html>

<?php } 

$pdo = null;

?>