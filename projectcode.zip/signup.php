<?php session_start(); ?>

<!doctype html>

<html>

	<head>

		<title>FoodFood - Sign Up!</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="style/style.css">
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

	</head>

	<body>

		<div class="signupimage">
			<img src="logosmall.png">
		</div>
		<h1 style="margin-top:10px;">Sign Up for FoodFood!</h1>

		<section id="signupSec">

			<form id="signup" enctype="multipart/form-data" action="signup-process.php" method="POST">

				<p style="text-align:right;">* denotes required field</p>

				<label for="email">email: *</label>

				<input type="text" name="email" />
				<br><br>

				<label for="first">first name: *</label>

				<input type="text" name="first" />
				<br><br>
				<label for="last">last name: *</label>

				<input type="text" name="last" />
				<br><br>
				<label for="town">city/town: </label>

				<input type="text" name="town" />
				<br><br>	
				<label for="province">province: *</label>
 
				<select name="province">
					<option value="Newfoundland">Newfoundland</option>
					<option value="PEI">Prince Edward Island</option>
					<option value="NovaScotia">Nova Scotia</option>
					<option value="NewBrunswick">New Brunswick</option>
					<option value="Quebec">Quebec</option>
					<option value="Ontario">Ontario</option>
					<option value="Manitoba">Manitoba</option>
					<option value="Saskatchewan">Saskatchewan</option>
					<option value="Alberta">Alberta</option>
					<option value="BC">British Columbia</option>
				</select>
				<br><br>
				<label for="about">about me: *</label>

				<textarea rows="10" cols="32" name="about" placeholder="A few words to describe yourself..."></textarea>
				<br><br>
				<label for="file_upload">profile photo (jpg, gif, or png - max. 2MB):</label>

				<input type="hidden" name="MAX_FILE_SIZE" value="2048000" />
				<input type='file' name='file_upload' />
				<br><br><br><br>

				<label for="website">website:</label>

				<input type="text" name="website" defaultValue="http://" />
				<br><br>
				<label for="newUser">username: *</label>

				<input type="text" name="newUser" />
				<br><br>
				<label for="newPassword">password: *</label>

				<input type="password" name="newPassword" />
				<br><br><br>
				<center>
					<input type="submit" id="submit" style="height:50px;" value="Create Account" />
				</center>
				<br><br>
			</form>

		</section>

	</body>

</html>