<?php session_start(); ?>

<!doctype html>

<html>

<head>

<title>Food Food - Login</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="style/style.css">
<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

</head>

<body>
<section id="logo1">
<img src="logo.png">
</section>

<section id="loginSec">

<form id="login" action="login-process.php" method="POST">

<label for="login">USERNAME:</label>

<input type="text" name="login" />

<br><br>

<label for="password">PASSWORD:</label>

<input type="password" name="password" />
<br><br><br>
<center>
<input type="Submit" value="Login!" id="submit" style="width: 120px; height: 40px;"/>
<br><br>
<p>
New to FoodFood? <a href="signup.php">Sign up!</a>
</p>
</center>

</form>
</section>

</body>

</html>