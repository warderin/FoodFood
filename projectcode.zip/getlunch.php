<?php 
header('Content-type: application/xml');

if(!$dbconnect = mysql_connect('localhost', 'warderi', '991252147')) {
   echo "Connection failed to the host 'localhost'.";
   exit;
} // if
if (!mysql_select_db('warderi')) {
   echo "Cannot connect to database 'test'";
   exit;
} // if

$table_id = 'recipes';
$query = "SELECT * FROM $table_id WHERE `category` = 'Lunch'";
$dbresult = mysql_query($query, $dbconnect);



$doc = new DomDocument("1.0", "UTF-8");

$root = $doc->createElement('recipes');
$root = $doc->appendChild($root);

while($row = mysql_fetch_assoc($dbresult)) {


  $occ = $doc->createElement('recipe');
  $occ = $root->appendChild($occ);

  foreach ($row as $fieldname => $fieldvalue) {

    $child = $doc->createElement($fieldname);
    $child = $occ->appendChild($child);

    $value = $doc->createTextNode($fieldvalue);
    $value = $child->appendChild($value);


  } // foreach
} // while

$xml = $doc->saveXML();

echo $xml;

?> 