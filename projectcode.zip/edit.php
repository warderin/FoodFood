<?php session_start(); 

$recipeID = $_POST['edit'];

?>

<!doctype html>

<html>

<head>

<title>FoodFood - Edit Recipe</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="style/style.css">
<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

</head>

<body>

<?php 
if(!$_SESSION['userID']) {
	// header("login.php"); //redirect
	?>
	<h2 style="text-align:center">Please log in here: <a href='login.php'>Login Page</a></h2>
	<?php
	exit();
}
else {

$dsn = "mysql:host=localhost;dbname=warderi";
$dbusername='warderi';
$dbpassword='991252147';

$pdo = new PDO($dsn, $dbusername, $dbpassword);

$stmt = $pdo->prepare("SELECT `title`, `category`, `source`, `ingredients`, `instructions` FROM `recipes` WHERE `recipeID` = '" . $recipeID . "' ");

$stmt->execute();

$row = $stmt->fetch();

$_SESSION['rID'] = $recipeID;

?>

<section class="mainlogo">
<div id="mainlink">
<a href="addrecipe.php">add a new recipe</a>
</div>
<div id="mainimage">
<a href="main.php"><img src="images/logosmall.png"></a>
</div>
<div id="mainlink">
<a href="user.php">my account</a>
</div>
</section>

<h1 style="clear:both;">Edit Recipe</h1>

<section id="recipeSec">

<form id="recipe" method="POST">

<label for="title">title:</label>

<?php echo '<input type="text" name="title" value="' . $row['title'] . '" />' ?>
<br><br>
<label for="source">source:</label>

<?php echo '<input type="text" name="source" value="' . $row['source'] . '" />' ?>
<br><br>
<label for="category">category:</label>

<?php echo '<select name="category" value="' . $row['category'] . '" />' ?>

<option>Breakfast</option>
<option>Lunch</option>
<option>Dinner</option>
<option>Dessert</option>

</select>
<br><br>
ingredients:

<?php echo '<textarea rows="10" cols="54" name="ingredients">' . $row['ingredients'] . '</textarea>' ?>
<br><br>
instructions:

<?php echo '<textarea rows="10" cols="54" name="instructions">' . $row['instructions'] . '</textarea>' ?>
<br><br>
<center>
<input type="button" style="height:50px;" onclick="var e = document.getElementById('recipe'); e.action='editprocess.php'; e.submit();" value="Submit Changes">
<p>or</p>
<input type="button" style="height:50px;" onclick="var e = document.getElementById('recipe'); e.action='deleterecipe.php'; e.submit();" value="Delete Recipe">
</center>
<br><br>
</form>
</section>

<div id="logout"><a href="logout-process.php">Log me out</a></div>

</body>

</html>

<?php } 

$pdo = null;

?>