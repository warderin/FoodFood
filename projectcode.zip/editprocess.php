<?php session_start(); 

$title = $_POST['title'];
$source = $_POST['source'];
$category = $_POST['category'];
$ingredients = $_POST['ingredients'];
$instructions = $_POST['instructions'];
$rID = $_SESSION['rID'];


?>


<!DOCTYPE html>

<html>

<head>
<title>FoodFood - Edit Recipe</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="style/style.css">
<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

</head>

<body>

<?php
// check database for correct username/password

$dsn = "mysql:host=localhost;dbname=warderi";
$dbusername='warderi';
$dbpassword='991252147';

$pdo = new PDO($dsn, $dbusername, $dbpassword);

$stmt = $pdo->prepare("UPDATE `recipes` SET `title` = '" . $title ."', `source` = '" . $source ."', `category` = '" . $category ."', `ingredients` = '" . $ingredients ."', `instructions` = '" . $instructions ."'  WHERE `recipeID` = '" . $rID . "' ");

$stmt->execute();

$row = $stmt->fetch();

$stmt2 = $pdo->prepare("SELECT `recipeID`, `title` FROM `recipes` WHERE `title` = '" . $title . "'  ");

$stmt2->execute();

$row2 = $stmt2->fetch();

// print_r($row); //recursive print out

if($row2) {

?>

<h2 style="margin-top:75px;text-align:center"><?php echo($row2['title']); ?> has been updated!</h2>
<h1 style="text-align:center"><a href="main.php">Back to foodfood!</a></h1>

<?php


}

else {

?>

<h2 style="margin-top:75px;text-align:center;">Sorry, something went wrong, please <a href="edit.php">try again</a></h2>

<?php
}

$pdo = null;

?>

</body>

</html>