<?php 

	session_start(); 

?>


<!DOCTYPE html>

<html>

	<head>
		<title>FoodFood - Delete Recipe</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="style/style.css">
		<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>
	</head>

	<body>

<?php

$rID = $_SESSION['rID'];

$dsn = "mysql:host=localhost;dbname=warderi";
$dbusername='warderi';
$dbpassword='991252147';

$pdo = new PDO($dsn, $dbusername, $dbpassword);

$stmt = $pdo->prepare("DELETE FROM `warderi`.`recipes` WHERE `recipes`.`recipeID` = '" . $rID . "'");

$stmt->execute();

$stmt2 = $pdo->prepare("GET * FROM `recipes` where `recipeID` = '" . $rID . "' ");

$stmt2->execute();

$row = $stmt->fetch();

if ($row['recipeID'] = $rID) {

?>

		<h2 style="margin-top:75px;text-align:center">Recipe Deleted!</h2>
		<h1 style="text-align:center"><a href="main.php">Back to foodfood!</a></h1>

<?php

}

else {

?>

		<h2 style="margin-top:75px;text-align:center;">Sorry, something went wrong, please <a href="addrecipe.php">try again</a></h2>

<?php

}

$pdo = null;

?>