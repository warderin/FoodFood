<?php session_start(); 

$userLogin = $_POST['login'];
$userPassword = $_POST['password'];

?>


<!DOCTYPE html>

<html>

<head>
<title>Login Done</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="style/style.css">
<link href='http://fonts.googleapis.com/css?family=Ubuntu|Sintony|Raleway:400,200' rel='stylesheet' type='text/css'>

</head>

<body>

<?php
// check database for correct username/password

$dsn = "mysql:host=localhost;dbname=warderi";
$dbusername='warderi';
$dbpassword='991252147';

$pdo = new PDO($dsn, $dbusername, $dbpassword);

$stmt = $pdo->prepare("SELECT `userID`, `firstName`, `username` FROM `users` WHERE `username` = '" . $userLogin . "' AND `password` = '" . $userPassword . "' ");

$stmt->execute();

$row = $stmt->fetch();

// print_r($row); //recursive print out

if($row) {

?>

<h2 style="margin-top:75px;text-align:center">Welcome, <?php echo($row['firstName']); ?> you are logged in!</h2>
<h1 style="text-align:center"><a href="main.php">Continue to foodfood!</a></h1>

<?php
$_SESSION['userID'] = $row['userID'];
$_SESSION['username'] = $userLogin;
}

else {

?>

<h2 style="margin-top:75px;text-align:center;">Sorry, something went wrong, please <a href="login.php">try again</a></h2>

<?php
}

$pdo = null;

?>

</body>

</html>

